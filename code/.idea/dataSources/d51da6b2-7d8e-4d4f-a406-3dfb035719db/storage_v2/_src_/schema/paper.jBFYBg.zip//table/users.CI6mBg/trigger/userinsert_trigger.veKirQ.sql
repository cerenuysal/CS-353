create trigger userInsert_trigger
  after INSERT
  on users
  for each row
  BEGIN
		IF NEW.privilege_level = 0 THEN
			INSERT INTO subscribers(subscriberID) VALUES (NEW.ID);
		ELSEIF NEW.privilege_level = 1 THEN
			INSERT INTO authors (authorID) VALUES (NEW.ID);
		ELSEIF NEW.privilege_level = 2 THEN
			INSERT INTO reviewers (reviewerID) VALUES (NEW.ID);
		ELSEIF NEW.privilege_level = 3 THEN
			INSERT INTO editors (editorID) VALUES (NEW.ID);
		END IF;
	END;

