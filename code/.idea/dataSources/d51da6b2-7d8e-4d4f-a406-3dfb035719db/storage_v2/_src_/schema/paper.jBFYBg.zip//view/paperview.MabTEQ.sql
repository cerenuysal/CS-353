create view paperview as
  select
    `author`.`authorID`                      AS `authorID`,
    `paper`.`users`.`name`                   AS `name`,
    `paper`.`users`.`lastname`               AS `lastname`,
    `paper`.`publications`.`ID`              AS `ID`,
    `paper`.`publications`.`publicationDate` AS `publicationDate`,
    `s`.`organizationID`                     AS `organizationID`,
    `paper`.`publications`.`title`           AS `PublicationTitle`,
    `o`.`title`                              AS `OrganizationTitle`,
    `paper`.`users`.`mail`                   AS `mail`,
    `paper`.`publications`.`weblink`         AS `weblink`
  from ((((`paper`.`publications`
    left join `paper`.`submitted` `s` on ((`paper`.`publications`.`ID` = `s`.`publicationID`))) left join
    `paper`.`organizations` `o` on ((`s`.`organizationID` = `o`.`ID`))) left join `paper`.`publicationauthors` `author`
      on ((`paper`.`publications`.`ID` = `author`.`pubID`))) left join `paper`.`users`
      on ((`paper`.`users`.`ID` = `author`.`authorID`)));

